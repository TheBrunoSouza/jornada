CREATE TRIGGER TRG_REGFECHAMENTO
BEFORE INSERT
  ON BANCO_HORAS_REGFECHAMENTO
FOR EACH ROW
  begin  
   if inserting then 
      if :NEW."ID_REGFECHAMENTO" is null then 
         select SEQ_REG_FECHAMENTO.nextval into :NEW."ID_REGFECHAMENTO" from dual; 
      end if; 
   end if; 
end;
/
