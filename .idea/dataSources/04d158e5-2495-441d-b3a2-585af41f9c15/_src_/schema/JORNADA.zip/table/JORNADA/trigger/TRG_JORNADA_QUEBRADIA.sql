CREATE TRIGGER TRG_JORNADA_QUEBRADIA
BEFORE INSERT OR UPDATE
  ON JORNADA
FOR EACH ROW
  DECLARE
  sit   NUMBER(5);
  idJor NUMBER(10);
  tmpDt DATE;
  pragma autonomous_transaction;
BEGIN
  IF(:NEW.data_fim IS NOT NULL AND TRUNC(:NEW.data_fim)>TRUNC(:OLD.data_ini))THEN
--    UPDATE jornada SET
--    data_fim = to_date(to_char(:OLD.data_ini, 'DDMMYYYY')||'2359', 'DDMMYYYYHH24MI')
--    WHERE id_jornada = :OLD.id_jornada;

    tmpDt := :NEW.data_fim;
    :NEW.data_fim := to_date(to_char(:OLD.data_ini, 'DDMMYYYY')||'2359', 'DDMMYYYYHH24MI');
        
    INSERT INTO jornada_tmp
    (id_jornada, data_ini, data_fim, situacao, condutor, placa, situacao_ant, jornada_ant)
    VALUES
    (seq_jornada.nextval, to_date(to_char(tmpDt, 'DDMMYYYY')||'0000', 'DDMMYYYYHH24MI'), tmpDt, :OLD.situacao, 
     :OLD.condutor, :OLD.placa, :OLD.situacao, :OLD.id_jornada);
     
    COMMIT;
  END IF;
--  IF(:OLD.data_fim IS NULL AND TRUNC(:OLD.data_ini)<TRUNC(SYSDATE))THEN
--    DBMS_OUTPUT.PUT_LINE('UPDATE NA TRIGGER QUEBRADIA');
--    UPDATE jornada SET
--    data_fim = to_date(to_char(:OLD.data_ini, 'DDMMYYYY')||'2359', 'DDMMYYYYHH24MI')
--    WHERE id_jornada = :OLD.id_jornada;
--  END IF;
END;
/
