CREATE TRIGGER TRG_JORNADA
BEFORE INSERT OR UPDATE
  ON JORNADA
FOR EACH ROW
  DECLARE
--  auxDt     VARCHAR2(8);
--  auxDtIni  VARCHAR2(8);
  auxAlerta VARCHAR2(10);
  auxSit    NUMBER(5);
  auxEmp    NUMBER(10);
  auxTmp    NUMBER(10);
--  pragma autonomous_transaction;
BEGIN
  --consulta para verificar se tem que gerar alerta 
  --não gera alerta de regeracao, somente alerta em tempo real
  IF(updating AND :NEW.data_fim IS NOT NULL AND TRUNC(:NEW.data_fim)=TRUNC(SYSDATE))THEN
    IF(:NEW.situacao IS NOT NULL)THEN
      auxSit := :NEW.situacao;
    ELSE
      auxSit := :OLD.situacao;
    END IF;
    auxEmp := getEmpresa(:NEW.condutor);
    
    BEGIN 
      SELECT auxAlerta INTO auxAlerta
      FROM (SELECT CASE WHEN empresa = auxEmp
                        THEN 'empresa'
                        ELSE 'default' 
                   END AS auxAlerta
            FROM alerta_situacao
            WHERE situacao = auxSit
            ORDER BY empresa)
      WHERE ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      auxAlerta := null;
    END;
    
    IF(auxAlerta = 'empresa')THEN
      auxTmp := getIntervalToNumber(:OLD.data_ini, :NEW.data_fim);
      INSERT INTO alertas
      (id_alerta, descricao, data_hora, placa, condutor, jornada)
      (SELECT seq_alertas.nextval, alsit.descricao||': '||auxTmp, SYSDATE, :OLD.placa, :OLD.condutor, :OLD.id_jornada
       FROM alerta_situacao alsit
       WHERE alsit.empresa = auxEmp
       AND alsit.situacao = auxSit
       AND (alsit.tempo_max<=auxTmp OR alsit.tempo_min>auxTmp));
    ELSIF(auxAlerta = 'default')THEN
      auxTmp := getIntervalToNumber(:OLD.data_ini, :NEW.data_fim);
      INSERT INTO alertas
      (id_alerta, descricao, data_hora, placa, condutor, jornada)
      (SELECT seq_alertas.nextval, alsit.descricao||': '||auxTmp, SYSDATE, :OLD.placa, :OLD.condutor, :OLD.id_jornada
       FROM alerta_situacao alsit
       WHERE alsit.empresa IS NULL
       AND alsit.situacao = auxSit
       AND (alsit.tempo_max<=auxTmp OR alsit.tempo_min>auxTmp));
    END IF;
  END IF;
END;
/
