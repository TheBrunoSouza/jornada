CREATE TRIGGER TRG_BANCO_CONDUTOR
AFTER INSERT
  ON BANCO_CONDUTOR
FOR EACH ROW
  DECLARE
totalHoras      NUMBER := 0;
start_date      NUMBER;
end_date        NUMBER;
minSem          NUMBER;
minSab          NUMBER;
idEmpresa       NUMBER;
idBancoHoras    NUMBER;
dtChar          VARCHAR(8);
charFeriado     CHAR(1);
BEGIN
  start_date    := to_number(to_char(to_date(''||:NEW.DATA_INI||'', 'DD/MM/YYYY HH24:MI'), 'j'));
  end_date      := to_number(to_char(to_date(''||:NEW.DATA_FIM||'', 'DD/MM/YYYY HH24:MI'), 'j'));
  idBancoHoras  := :NEW.ID_BANCO_HORAS;
  
  SELECT empresa, min_semana, min_sab INTO idEmpresa, minSem, minSab
  FROM banco_horas
  WHERE id_banco_horas = idBancoHoras;
  
  FOR cur_r IN start_date..end_date LOOP
    dtChar := to_char(to_date(cur_r, 'j'), 'DDMMYYYY');
    charFeriado :=  pkg_banco_horas.consultaFeriado(dtChar, idEmpresa);
    
    IF(charFeriado = 'F') THEN
      DBMS_OUTPUT.PUT_LINE('NAO FERIADO'||charFeriado);
      IF(to_char(to_date(cur_r, 'j'), 'D') = '7') THEN
        totalHoras := totalHoras + minSab;
      ELSIF (to_char(to_date(cur_r, 'j'), 'D') != '1') THEN
        totalHoras := totalHoras + minSem;
      END IF;          
    ELSE
      DBMS_OUTPUT.PUT_LINE('FERIADO'||charFeriado);
    END IF;
    
  END LOOP;
  
  UPDATE banco_horas
  SET min_total = totalHoras
  WHERE id_banco_horas = idBancoHoras;
END;
/
