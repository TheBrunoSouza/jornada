CREATE TRIGGER TRG_CONFIGURACAO
AFTER INSERT
  ON CONFIGURACAO
FOR EACH ROW
  DECLARE
  idConfSit NUMBER(10);
BEGIN

  IF(:NEW.ID_CONFIGURACAO IS NOT NULL AND :NEW.EMPRESA IS NOT NULL)THEN
    FOR x IN (SELECT id_config_situacao, configuracao, ativo, hora_ini, hora_fim, tempo, data_cad, next_sit, situacao, tempo_min, total, tempo_desconto
              FROM configuracao_situacao
              WHERE configuracao = 1)
    LOOP  
    
      SELECT seq_config_situacao.nextval INTO idConfSit
      FROM DUAL;
      
      INSERT INTO configuracao_situacao
      (id_config_situacao, configuracao, ativo, hora_ini, hora_fim, tempo, data_cad, next_sit, situacao, tempo_min, total, tempo_desconto)
      VALUES
      (idConfSit, :NEW.ID_CONFIGURACAO, x.ativo, x.hora_ini, x.hora_fim, x.tempo, SYSDATE, x.next_sit, x.situacao, x.tempo_min, x.total, x.tempo_desconto);
      
      INSERT INTO config_situacao_codigo
      (config_situacao, codigo, dia, situacao)
      (SELECT idConfSit, codigo, dia, situacao 
       FROM config_situacao_codigo
       WHERE config_situacao = x.id_config_situacao);
      
    END LOOP;
  
  END IF;
  
END;
/
