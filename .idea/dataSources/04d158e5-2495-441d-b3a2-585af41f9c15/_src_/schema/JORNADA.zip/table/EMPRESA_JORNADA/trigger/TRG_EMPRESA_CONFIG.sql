CREATE TRIGGER TRG_EMPRESA_CONFIG
BEFORE INSERT OR UPDATE OF EMPRESA, TECLADO_ALFA
  ON EMPRESA_JORNADA
FOR EACH ROW
  DECLARE
  cod  NUMBER(5);
  cod2 NUMBER(5);
  usu_aux VARCHAR(30);
BEGIN
  --null;
/*
802 - Jornada Iniciada
803 - Jornada Finalizada
804 - Refeição Iniciada
805 - Refeição Finalizada
806 - Descanso Iniciado
807 - Descanso Finalizado
808 - Espera Iniciada
809 - Espera Finalizada
816 - Manobra Iniciada
817 - Manobra Finalizada*/
  /******** RELATORIO DE DIARIAS DE CONDUTOR***************************/
  IF :NEW.teclado_alfa = 'T' THEN
    
    usu_aux := CASE WHEN (:NEW.usuario_cad IS NULL) 
                    THEN 'SISTEMA' 
                    ELSE :NEW.usuario_cad 
               END;

    FOR aux IN (SELECT placa, acessorio
                FROM (SELECT va.placa, va.acessorio
                      FROM monitoramento.veiculo_empresa ve, monitoramento.veiculo_acessorio va
                      WHERE ve.empresa = :NEW.empresa 
                      AND ve.placa = va.placa
                      AND va.acessorio IN (SELECT id_acessorio
                                           FROM monitoramento.acessorios
                                           WHERE tipo_acessorio = 5)
                      UNION ALL                     
                      SELECT va.placa, va.acessorio
                      FROM monitoramento.veiculo, monitoramento.veiculo_acessorio va
                      WHERE veiculo.empresa = :NEW.empresa 
                      AND veiculo.placa = va.placa
                      AND va.acessorio IN (SELECT id_acessorio
                                           FROM monitoramento.acessorios
                                           WHERE tipo_acessorio = 5))
                GROUP BY placa, acessorio
                ORDER BY placa)
    LOOP
      /*****GRAVA MENSAGENS NO TECLADO****/
      IF(aux.acessorio >= 24)THEN
        
        DBMS_OUTPUT.PUT_LINE('
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, '||aux.placa||', 0404~, 48INICIO DE JORNADA, #, SYSDATE, '||usu_aux||', T)');


        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~', '48INICIO DE JORNADA', '#', SYSDATE, usu_aux, 'T');
        
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','47FIM DE JORNADA', '#', SYSDATE, usu_aux, 'T');
        
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','46INICIO DE REFEICAO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','45FIM DE REFEICAO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','44INICIO DE DESCANSO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','43FIM DE DESCANSO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','42INICIO DE ESPERA', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '0404~','41FIM DE ESPERA', '#', SYSDATE, usu_aux, 'T');
      
      ELSIF(aux.acessorio IS NOT NULL) THEN
        DBMS_OUTPUT.PUT_LINE('
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, '||aux.placa||', 0404~, 48INICIO DE JORNADA, #, SYSDATE, '||usu_aux||', T)');


        
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@', '2048INICIO DE JORNADA', '#', SYSDATE, usu_aux, 'T');
        
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2047FIM DE JORNADA', '#', SYSDATE, usu_aux, 'T');
        
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2046INICIO DE REFEICAO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2045FIM DE REFEICAO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2044INICIO DE DESCANSO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2043FIM DE DESCANSO', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2042INICIO DE ESPERA', '#', SYSDATE, usu_aux, 'T');
  
        INSERT INTO monitoramento.msg
        (id_msg, placa, inicio, mensagem, fim, data_db, requerente, acessorio)
        VALUES 
        (monitoramento.seq_msg.NEXTVAL, aux.placa, '25@','2041FIM DE ESPERA', '#', SYSDATE, usu_aux, 'T');
      
      END IF;
      
      --excluindo as mensagens do sistema
      DELETE FROM monitoramento.mensagem_alfa
      WHERE placa = aux.placa 
      AND n_msg IN (41, 42, 43, 44, 45, 46, 47, 48);

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'INICIO DE JORNADA', '48', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'FIM DE JORNADA', '47', 'R');
      
      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'INICIO DE REFEICAO', '46', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'FIM DE REFEICAO', '45', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'INICIO DE DESCANSO', '44', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'FIM DE DESCANSO', '43', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'INICIO DE ESPERA', '42', 'R');

      INSERT INTO monitoramento.mensagem_alfa
      (id_mensagem, placa, mensagem, n_msg, enviada_recebida)
      VALUES 
      (monitoramento.seq_mensagem_alfa.NEXTVAL, aux.placa, 'FIM DE ESPERA', '41', 'R');

      /*** INSERE NA TABELA EVENTO_VEICULO *******/
      DELETE FROM monitoramento.evento_veiculo 
      WHERE placa = aux.placa
      AND codigo IN (802, 803, 804, 805, 806, 807, 808, 809);
      
      FOR auxCod IN (SELECT codigo, descricao, evento_descricao
                     FROM monitoramento.evento_acessorio
                     WHERE codigo IN (802, 803, 804, 805, 806, 807, 808, 809)
                     GROUP BY codigo, descricao, evento_descricao) 
      LOOP
        INSERT INTO monitoramento.evento_veiculo
        (id_evento_codigo, placa, codigo, descricao, enviada_recebida, gprs, sms, dtmf, com_parametro, acessorio, acessorio_id, evento_descricao)
        VALUES
        (monitoramento.seq_evento_veiculo.nextval, aux.placa, auxCod.codigo, auxCod.descricao, 'R', 'T', 'F', 'F', 'F', 'F', aux.acessorio, auxCod.evento_descricao);
      END LOOP;

      /************************************/
      BEGIN
         SELECT codigo INTO cod
         FROM monitoramento.evento_veiculo
         WHERE placa = aux.placa 
         AND evento_descricao = 87;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        cod := NULL;
      END;
      
      BEGIN
         SELECT codigo INTO cod2
         FROM monitoramento.evento_veiculo
         WHERE placa = aux.placa AND evento_descricao = 88;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        cod := NULL;
      END;
      
      IF (cod IS NOT NULL) THEN
      
        DELETE FROM monitoramento.retorna_evento
        WHERE placa = aux.placa 
        AND codigo_ret IN (802, 803, 804, 805, 806, 807, 808, 809, 816, 817);

        --INSERE RETORNO JORNADA INICIADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 802, 'F', '48', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 802, 'F', '48', 'R');

        --INSERE RETORNO JORNADA FINALIZADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 803, 'F', '47', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 803, 'F', '47', 'R');

        --INSERE RETORNO REFEICAO INICIADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 804, 'F', '46', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 804, 'F', '46', 'R');

        --INSERE RETORNO REFEICAO FINALIZADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 805, 'F', '45', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 805, 'F', '45', 'R');

        --INSERE RETORNO DESCANSO INICIADO
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 806, 'F', '44', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 806, 'F', '44', 'R');

        --INSERE RETORNO DESCANSO FINALIZADO
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 807, 'F', '43', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 807, 'F', '43', 'R');

        --INSERE RETORNO ESPERA INICIADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 808, 'F', '42', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 808, 'F', '42', 'R');

        --INSERE RETORNO ESPERA FINALIZADA
        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod, 809, 'F', '41', 'R');

        INSERT INTO monitoramento.retorna_evento
        (id_retorna_evento, placa, codigo, codigo_ret, acessorio_ret, parametro, envia_recebe)
        VALUES 
        (monitoramento.seq_retorna_evento.NEXTVAL, aux.placa, cod2, 809, 'F', '41', 'R');

      END IF;
      
      
      
    END LOOP;
  END IF;

END;
/
