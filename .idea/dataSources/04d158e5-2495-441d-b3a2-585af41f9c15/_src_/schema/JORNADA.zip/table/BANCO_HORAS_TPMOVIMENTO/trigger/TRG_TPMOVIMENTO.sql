CREATE TRIGGER TRG_TPMOVIMENTO
BEFORE INSERT
  ON BANCO_HORAS_TPMOVIMENTO
FOR EACH ROW
  begin  
   if inserting then 
      if :NEW."ID_TPMOVIMENTO" is null then 
         select SEQ_TP_MOVIMENTO.nextval into :NEW."ID_TPMOVIMENTO" from dual; 
      end if; 
   end if; 
end;
/
