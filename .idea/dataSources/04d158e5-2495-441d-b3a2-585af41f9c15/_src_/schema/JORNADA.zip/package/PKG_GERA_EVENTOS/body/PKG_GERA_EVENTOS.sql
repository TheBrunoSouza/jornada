CREATE PACKAGE BODY PKG_GERA_EVENTOS AS
/*
--busca os eventos na tabela de monitoramento.evento_log e gera os eventos de jornada na tabela bkp_eventos_jornada
declare
  start_date number;
  end_date number;
begin
  for aux in (SELECT id_condutor, empresa 
              FROM monitoramento.condutor 
              WHERE empresa = 98692 
              AND ativo = 'T') loop
    start_date := to_number(to_char(to_date('2017-02-01', 'yyyy-MM-dd'), 'j'));
    end_date   := to_number(to_char(to_date('2017-02-27', 'yyyy-MM-dd'), 'j'));
    dbms_output.put_line(aux.id_condutor||' - '||start_date);  
    for cur_r in start_date..end_date loop
--     pkg_jornada_correcao.beginjornada(aux.id_condutor, aux.empresa, to_date(cur_r, 'j'));
      PKG_GERA_EVENTOS.getdados(aux.id_condutor, aux.empresa, to_date(cur_r, 'j'), null);
    end loop;
  END LOOP;
  COMMIT;
END;

*/
  PROCEDURE getDados(cond NUMBER, emp NUMBER, dtini DATE, dtfim DATE) AS
    sqlTxt VARCHAR2(2000);
    auxCursor SYS_REFCURSOR;
    varStringPKGCall VARCHAR2(2000);
    
    status_new bkp_status_teclado%ROWTYPE;
    status_old bkp_status_teclado%ROWTYPE;
    eventos monitoramento.evento_log%ROWTYPE;
    empAux NUMBER(10);
    sqlAux VARCHAR2(200) := '';
  BEGIN
    
    sqlAux := CASE WHEN cond IS NOT NULL THEN sqlAux||' AND evento_log.condutor = '||cond ELSE sqlAux END;
    sqlAux := CASE WHEN emp IS NOT NULL THEN sqlAux||' AND condutor.empresa = '||emp ELSE sqlAux END;
--    sqlAux := CASE WHEN dtini IS NOT NULL THEN sqlAux||' AND evento_log.data_hora >= '''||dtini||'''' ELSE sqlAux END;
    sqlAux := CASE WHEN dtini IS NOT NULL 
                   THEN sqlAux||' AND TRUNC(evento_log.data_hora) >= to_date('''||to_char(dtini, 'DDMMYYYY')||''', ''DDMMYYYY'')'
                   ELSE sqlAux 
              END;
    sqlAux := CASE WHEN dtfim IS NOT NULL 
                   THEN sqlAux||' AND TRUNC(evento_log.data_hora) < to_date('''||to_char(dtfim, 'DDMMYYYY')||''', ''DDMMYYYY'')'
                   WHEN dtfim IS NULL AND dtini IS NOT NULL 
                   THEN sqlAux||' AND TRUNC(evento_log.data_hora) < to_date('''||to_char(dtini, 'DDMMYYYY')||''', ''DDMMYYYY'')+1'
                   ELSE sqlAux 
              END;
    --sqlAux := CASE WHEN dtfim IS NOT NULL THEN sqlAux||' AND evento_log.data_hora < '''||dtfim||'''' ELSE sqlAux END;
    
    sqlTxt := 'SELECT id_evento, placa, data_db, data_hora, codigo, parametro, condutor, empresa
               FROM monitoramento.evento_log
               JOIN monitoramento.condutor ON id_condutor = evento_log.condutor 
                                           AND condutor.empresa IN (SELECT empresa 
                                                                    FROM monitoramento.veiculo_empresa 
                                                                    WHERE veiculo_empresa.placa = evento_log.placa)
               WHERE codigo IN (1654, 1655, 5015, 2) --codigo 2 é gravado direto na pkg_jornada_teclado
               '||sqlAux||'
               AND condutor IS NOT NULL
               ORDER BY condutor, data_hora';
    
    DBMS_OUTPUT.PUT_LINE('SQL:'||sqlTxt);
    OPEN auxCursor FOR sqlTxt;
    LOOP
      FETCH auxCursor INTO eventos.id_evento, eventos.placa, eventos.data_db, eventos.data_hora, eventos.codigo, eventos.parametro, eventos.condutor, empAux;
      EXIT WHEN auxCursor%NOTFOUND;
      BEGIN
        empAux:= CASE WHEN emp IS NOT NULL THEN emp ELSE empAux END;
--        DBMS_OUTPUT.PUT_LINE('PROC:checkStatus('||eventos.placa||', '||eventos.data_hora||', '||eventos.parametro||', '||eventos.condutor||', '||empAux||');');
        checkStatus(eventos.placa, eventos.data_hora, eventos.parametro, eventos.condutor, empAux);
      END;
    END LOOP;

  END getDados;
  
  
  PROCEDURE checkStatus(placa_aux IN VARCHAR2, data_aux IN DATE, pacote_aux IN VARCHAR2, condutor_aux number, empresa_aux integer) AS
    aux CHAR(2);
    bit CHAR(8);
    cod NUMBER(4);
    seg NUMBER (10,9) := 0.000011574;
    status_new bkp_status_teclado%ROWTYPE;
    status_old bkp_status_teclado%ROWTYPE;
    modelo_evento_aux number;
    existe char(1); 
    auxTmp NUMBER(1) := 0;
  BEGIN
--    DELETE FROM bkp_eventos_jornada
--    WHERE condutor = condutor_aux
--    AND TRUNC(data_hora) = TRUNC(data_aux);
          
    aux := UPPER(SUBSTR(pacote_aux,3,2));
    bit := dec2bin(hex2dec(aux));
    
    status_new.data     := data_aux;
    status_new.jornada  := REPLACE(REPLACE(SUBSTR(bit,8,1),'1','T'),'0','F');
    status_new.refeicao := REPLACE(REPLACE(SUBSTR(bit,7,1),'1','T'),'0','F');
    status_new.descanso := REPLACE(REPLACE(SUBSTR(bit,6,1),'1','T'),'0','F');
    status_new.espera   := REPLACE(REPLACE(SUBSTR(bit,5,1),'1','T'),'0','F');
    status_new.aux1     := REPLACE(REPLACE(SUBSTR(bit,4,1),'1','T'),'0','F');
    status_new.aux2     := REPLACE(REPLACE(SUBSTR(bit,3,1),'1','T'),'0','F');
    status_new.reserva  := REPLACE(REPLACE(SUBSTR(bit,2,1),'1','T'),'0','F');
    status_new.manobra  := REPLACE(REPLACE(SUBSTR(bit,1,1),'1','T'),'0','F');
          
    status_new.condutor := condutor_aux;
    
    existe := 'T';
    BEGIN
      /*BUSCA DIRETO PELO ID DO CONDUTOR*/
      SELECT * INTO status_old 
      FROM (SELECT *
            FROM bkp_status_teclado 
            WHERE condutor = condutor_aux
            ORDER BY data DESC)
      WHERE ROWNUM=1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      BEGIN
          DBMS_OUTPUT.PUT_LINE('NÃO ENCONTROU REGISTRO PARA O CONDUTOR->'||condutor_aux||' - '||empresa_aux);
          INSERT INTO bkp_status_teclado (condutor,chaveiro,empresa) VALUES(condutor_aux,null,empresa_aux);
          SELECT * INTO status_old FROM bkp_status_teclado WHERE condutor = condutor_aux;
      EXCEPTION WHEN OTHERS THEN
          existe := 'F';
      END;
    END;
              
    IF (existe='T') then
      status_new.chaveiro  := status_old.chaveiro;
      status_new.empresa  := status_old.empresa;
        
      /**/
      IF(status_new.jornada<>status_old.jornada AND status_new.jornada = 'T') THEN
        insertEvento(placa_aux, condutor_aux, 802, data_aux, pacote_aux);
      END IF;
      
      IF(status_new.refeicao<>status_old.refeicao) THEN
        cod := CASE WHEN status_new.refeicao = 'T' THEN 804 ELSE 805 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.descanso<>status_old.descanso) THEN
        cod := CASE WHEN status_new.descanso = 'T' THEN 806 ELSE 807 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.espera<>status_old.espera) THEN
        cod := CASE WHEN status_new.espera = 'T' THEN 808 ELSE 809 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.aux1<>status_old.aux1) THEN
        cod := CASE WHEN status_new.aux1 = 'T' THEN 810 ELSE 811 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.aux2<>status_old.aux2) THEN
        cod := CASE WHEN status_new.aux2 = 'T' THEN 812 ELSE 813 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.reserva<>status_old.reserva) THEN
        cod := CASE WHEN status_new.reserva = 'T' THEN 814 ELSE 815 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.manobra<>status_old.manobra) THEN
        cod := CASE WHEN status_new.manobra = 'T' THEN 816 ELSE 817 END;
        insertEvento(placa_aux, condutor_aux, cod, data_aux, pacote_aux);
      END IF;
      IF(status_new.jornada<>status_old.jornada AND status_new.jornada = 'F') THEN
        insertEvento(placa_aux, condutor_aux, 803, data_aux, pacote_aux);
      END IF;
      UPDATE bkp_status_teclado SET ROW = status_new WHERE condutor = condutor_aux;
    END IF;
  END checkStatus;

  PROCEDURE insertEvento(plc VARCHAR2, cond NUMBER, cod NUMBER, dt DATE, dados VARCHAR2 ) AS
  BEGIN
    BEGIN  
      INSERT INTO bkp_eventos_jornada
      (id_evento, codigo, placa, condutor, data_hora, dados_hexa)
      VALUES
      (seq_eventos_jornada.nextval, cod, plc, cond, dt, dados);
    EXCEPTION WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('DADO DUPLICADO :'||plc||' | '||cond||' | '||dt||' | '||dados);
    END;
      
  END;
/*

--regera os eventos inserindo na tabela de evento_jornada_log do monitoramento
declare
  start_date number;
  end_date number;
begin
  start_date := to_number(to_char(to_date('2017-02-13', 'yyyy-MM-dd'), 'j'));
  end_date   := to_number(to_char(to_date('2017-02-14', 'yyyy-MM-dd'), 'j'));
  for cur_r in start_date..end_date loop
    PKG_GERA_EVENTOS.corrigeEventos(to_date(cur_r, 'j'));
  end loop;
  COMMIT;
END;
*/
  PROCEDURE corrigeEventos(dt DATE) AS
    descEv VARCHAR2(80);
    sqlTxt VARCHAR2(2000);
    dtStr VARCHAR(8);
    sec   NUMBER(2,5);
    dtIni DATE;
    DtFim DATE;
    condAux NUMBER(10) := null;
  BEGIN
  
    FOR aux IN (SELECT condutor, placa, data_hora, codigo
                FROM bkp_eventos_jornada
                WHERE TRUNC(data_hora) = TRUNC(dt)
                --AND condutor = 219783
                ORDER BY condutor, data_hora)
    LOOP            
      dtStr := to_char(dt, 'DDMMYYYY');
      dtIni := aux.data_hora-1/1440;
      dtFim := aux.data_hora+1/1440;
      
      IF(condAux IS NULL OR condAux<>aux.condutor)THEN
        BEGIN
          EXECUTE IMMEDIATE 'DELETE FROM monitoramento.evento_'||dtStr||' 
                             WHERE placa = :1
                             AND condutor = :2
                             --AND TRUNC(data_hora) = :3
                             AND codigo IN (802, 803, 804, 805, 806, 807, 808, 809, 816, 817)'
          USING aux.placa, aux.condutor;--, TRUNC(aux.data_hora); 
        EXCEPTION WHEN OTHERS THEN 
          DBMS_OUTPUT.PUT_LINE ('[DELETE]'||SQLERRM);
        END;
        condAux := aux.condutor;
      END IF;
      
      sqlTxt := 'INSERT INTO monitoramento.evento
                (id_evento, enviada_recebida, meio_conexao, requerente, acessorio, modelo_aparelho, faturar,
                codigo, placa, id_condutor, data_hora)
                VALUES
                (monitoramento.seq_evento.nextval, ''R'',''GPRS'',''SISTEMA'',''F'',''6'',''F'',
                :1, :2, :3, :4)';
      DBMS_OUTPUT.PUT_LINE('SQL2:'||sqlTxt);
      BEGIN
        EXECUTE IMMEDIATE sqlTxt
        USING aux.codigo, aux.placa,  aux.condutor, aux.data_hora;
        EXCEPTION WHEN OTHERS THEN 
         DBMS_OUTPUT.PUT_LINE ('[INSERT]'||SQLERRM);
      END;
    END LOOP;
    
  END;
  
  FUNCTION dec2bin (numero IN NUMBER) RETURN VARCHAR2 IS
    binval VARCHAR2(64);
    n2     NUMBER := numero;
  BEGIN
    WHILE(n2>0) LOOP
       binval := MOD(n2,2) || binval;
       n2 := TRUNC(n2/2);
    END LOOP;
    RETURN TRIM(TO_CHAR(NVL(binval,'0'),'00000000'));
  END dec2bin;
  
  FUNCTION hex2dec (hexval IN CHAR) RETURN NUMBER IS
    i                 NUMBER;
    digits            NUMBER;
    result            NUMBER := 0;
    current_digit     CHAR(1);
    current_digit_dec NUMBER;
  BEGIN
    digits := LENGTH(hexval);
    FOR i IN 1..digits LOOP
       current_digit := SUBSTR(hexval, i, 1);
       IF current_digit IN ('A','B','C','D','E','F') THEN
          current_digit_dec := ASCII(current_digit) - ASCII('A') + 10;
       ELSE
          current_digit_dec := TO_NUMBER(current_digit);
       END IF;
       result := (result * 16) + current_digit_dec;
    END LOOP;
    RETURN result;
  END hex2dec;
  
END PKG_GERA_EVENTOS;
/
