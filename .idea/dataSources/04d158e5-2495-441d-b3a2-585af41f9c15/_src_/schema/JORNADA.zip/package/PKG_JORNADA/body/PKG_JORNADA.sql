CREATE PACKAGE BODY         PKG_JORNADA AS
/*
declare
  start_date number;
  end_date number;
begin
  start_date := to_number(to_char(to_date('2016-05-21', 'yyyy-MM-dd'), 'j'));
  end_date := to_number(to_char(to_date('2016-05-07', 'yyyy-MM-dd'), 'j'));
  for cur_r in start_date..end_date loop
   pkg_jornada_dev.beginjornada(193170, 47032,to_date(cur_r, 'j'));
  end loop;
  COMMIT;
end;
*/
  /*variaveis globais*/
  gblRepouso   NUMBER(2) := 4;
  gblJornada   NUMBER(2) := 5;
  gblRefeicao  NUMBER(2) := 6;
  gblDescanso  NUMBER(2) := 7;
  gblEspera    NUMBER(2) := 8;
  gblHExtra    NUMBER(2) := 9;
  gblHExtra100 NUMBER(2) := 10;
  gblInativo   NUMBER(2) := 11;
  
  gblJor jornada%ROWTYPE;
  
  PROCEDURE beginjornada(cond NUMBER, emp NUMBER, dt DATE) IS
    p_cursor SYS_REFCURSOR;
    
    sqlAux VARCHAR2(2000);
    sqlAnd VARCHAR2(200);
    
    dtChar VARCHAR2(8);
    dthr   DATE;
    dtDb   DATE;
    lat    NUMBER(8,6);
    lon    NUMBER(9,6);
    cod    NUMBER(10);
    condAux NUMBER(10);
    evDesc VARCHAR2(100);
    plc    VARCHAR2(10);
    evParm VARCHAR2(200);
    empAux NUMBER(10);
    sitAux NUMBER(10);
    sitAuxFim NUMBER(10);
    
    plcAuxLoop  VARCHAR(10);
    empAuxLoop  NUMBER(10);
    condAuxLoop NUMBER(10);
    dtHrAuxLoop DATE;
    
    dtFimAux DATE;
  BEGIN
    dtChar := to_char(dt, 'DDMMYYYY');
    
    IF(cond IS NOT NULL)THEN
      sqlAnd := ' AND condutor.id_condutor = '||cond;
    ELSIF(emp IS NOT NULL)THEN 
      sqlAnd := ' AND condutor.empresa = '||emp||' AND condutor.ativo = ''T''';
    ELSE
      sqlAnd := ' AND condutor.empresa IN (SELECT empresa FROM empresa_jornada)';
    END IF;

    sqlAux := 'SELECT evento.data_hora, evento.data_db, evento.latitude, evento.longitude, evento.codigo, condutor.id_condutor, 
                       evento.descricao, evento.placa, evento.parametro, condutor.empresa
               FROM monitoramento.condutor
               LEFT JOIN monitoramento.evento_'||dtChar||' evento ON evento.condutor = condutor.id_condutor
                                                           AND evento.codigo IN (802, 803, 804, 805, 806, 807, 808, 809)
               LEFT JOIN monitoramento.veiculo ON veiculo.placa = evento.placa
               WHERE condutor.ativo = ''T''
               '||sqlAnd||'
               ORDER BY evento.condutor, evento.data_utc, evento.data_hora, evento.time_db';
    dbms_output.put_line(sqlAux||' - '||sqlAnd);
    OPEN p_cursor FOR sqlAux;
    LOOP FETCH p_cursor INTO dtHr, dtDb, lat, lon, cod, condAux, evDesc, plc, evParm, empAux;
    
      IF p_cursor%NOTFOUND THEN
        --se não encontrar nenhuma linha
        IF(p_cursor%ROWCOUNT=0)THEN
          dbms_output.put_line('[BEGIN JORNADA] INSERT REPOUSO O DIA TODO=>'||dt);
          setGblSit(cond, dt);--busca ultima situacao 
          IF(gblJor.id_jornada IS NULL) THEN
              IF(cond IS NOT NULL)THEN
                DELETE FROM jornada
                WHERE condutor = condAux
                AND trunc(data_ini) = trunc(dt);
                insertSit(cond, getEmpCond(cond), gblRepouso, to_date(dtChar||'0000', 'DDMMYYYYHH24MI'), null, getPlaca(cond, dt), null, null);

                DELETE FROM ALERTAS
                WHERE condutor = condAux
                AND TRUNC(data_hora) = TRUNC(dt);
              END IF;
          END IF;
        ELSE -- tem dados e este é a ultima passagem do loop
          /*verifica se é uma regeracao de historico para finalizar e não deixar em aberto*/
          endRegera(condAux, empAux, plc, dt);
        END IF;
      END IF;
          
    EXIT WHEN p_cursor%NOTFOUND;
    
      IF(p_cursor%ROWCOUNT=1 OR condAuxLoop<>condAux)THEN
        --insere repouso se o condutor não tiver nenhum evento no dia
        IF(condAux IS NOT NULL AND cod IS NULL)THEN
          
          dbms_output.put_line('[BEGIN JORNADA] INSERE REPOUSO DATA:'||dtHr||' | COD:'||cod||' | EMP:'||emp||' | COND:'||cond);
          DELETE FROM ALERTAS
          WHERE condutor = condAux
          AND TRUNC(data_hora) = TRUNC(dt);
        
          DELETE FROM jornada
          WHERE condutor = condAux
          AND trunc(data_ini) = trunc(dt);
          dtFimAux := CASE WHEN trunc(dt) = trunc(SYSDATE) THEN SYSDATE ELSE to_date(dtChar||'2359', 'DDMMYYYYHH24MI') END;
          insertSit(condAux, empAux, gblRepouso, to_date(dtChar||'0000', 'DDMMYYYYHH24MI'), dtFimAux, getPlaca(cond, dt), null, null);
          condAuxLoop := condAux;
        ELSE
          /*verifica se é uma regeracao de historico para finalizar e não deixar em aberto*/
          endRegera(condAuxLoop, empAuxLoop, plcAuxLoop, dtHrAuxLoop);
  
          plcAuxLoop := plc;
          empAuxLoop := empAux;
          condAuxLoop := condAux;
          dtHrAuxLoop := dt;
          
          DELETE FROM jornada
          WHERE condutor = condAux
          AND trunc(data_ini) = trunc(dt);
          
          DELETE FROM ALERTAS
          WHERE condutor = condAux
          AND TRUNC(data_hora) = TRUNC(dt);
        
          setGblSit(condAux, dtHr);--busca ultima situacao 
          IF(gblJor.id_jornada IS NULL AND dtHr >to_date(dtChar||'0000', 'DDMMYYYYHH24MI')) THEN
            insertSit(condAux, empAux, gblRepouso, to_date(dtChar||'0000', 'DDMMYYYYHH24MI'), null, plc, gblJor.situacao, gblJor.id_jornada);
          ELSE
            sitAuxFim := regraSituacaoFim(empAux, condAux, gblJor.situacao, null, dtHr, dtHr);
            IF(TRUNC(gblJor.data_ini) < TRUNC(dtHr))THEN
              insertSit(condAux, empAux, gblJor.situacao, to_date(dtChar||'0000', 'DDMMYYYYHH24MI'), null, plc, gblJor.situacao, gblJor.id_jornada);
            END IF;
          END IF;
          
        END IF;
      END IF;
      
      IF(cod IS NOT NULL)THEN
      --define a situacao a ser inserida
dbms_output.put_line('
          
[BEGIN JORNADA] -----------------------------------------------------------------------------------------------
[BEGIN JORNADA] DATA:'||dtHr||' | COD:'||cod||' | EMP:'||emp||' | COND:'||cond||' | DESC:'||evDesc||' | SIT:'||gblJor.situacao||' | PLC:'||plc||'
[BEGIN JORNADA] -----------------------------------------------------------------------------------------------
');
        --identifica qual a situacao que será iniciada
        sitAux := regraSituacao(empAux, condAux, gblJor.situacao, cod, dtHr, null);
        sitAuxFim := null;
        IF(gblJor.situacao IS NOT NULL AND sitAux<>gblJor.situacao)THEN
          sitAuxFim := regraSituacaoFim(empAux, condAux, gblJor.situacao, null, dtHr, dtHr);
        END IF;
        IF((sitAuxFim IS NULL OR sitAuxFim>0) AND sitAux<>gblJor.situacao)THEN
          updateSit(condAux, empAux, sitAux, null, dtHr, plc, gblJor.situacao, gblJor.id_jornada);
          insertSit(condAux, empAux, sitAux, dtHr, null, plc, gblJor.situacao, gblJor.id_jornada);
        END IF;--sitAuxIF
      END IF; -- cod is not null      
    END LOOP; -- fim loop fetch
    CLOSE p_cursor;    
  END;

/************************************************************************************************************************************************************/
/*********************************************************************INSERT E UPDATE ***********************************************************************/
/************************************************************************************************************************************************************/
  PROCEDURE insertSit(cond NUMBER, emp NUMBER, sit NUMBER, dtIni DATE, dtFim DATE, plc VARCHAR2, sitAnt NUMBER, jornAnt NUMBER) IS
    idJor NUMBER(10);
    auxSit NUMBER(10);
    auxDtIni VARCHAR2(8);
    auxDtFim VARCHAR2(8);
  BEGIN
    
    DBMS_OUTPUT.PUT_LINE('[INSERT SIT] 2 COND:'||cond||' | sit:'||sit||' | dtIni:'||dtIni||' | dtFim:'||dtFim);
    SELECT seq_jornada.nextval INTO idJor
    FROM DUAL;
    INSERT INTO jornada
    (id_jornada, situacao, data_ini, data_fim, condutor, placa, situacao_ant, jornada_ant)
    VALUES
    (idJor, sit, dtIni, dtFim, cond, plc, sitAnt, jornAnt);

    gblJor.id_jornada := idJor;
    gblJor.situacao   := sit;
    gblJor.data_ini   := dtIni;
    gblJor.data_fim   := dtFim;
    gblJor.condutor   := cond;
    gblJor.placa      := plc;
    
  END;
  
  PROCEDURE updateSit(cond NUMBER, emp NUMBER, sit NUMBER, dtIni DATE, dtFim DATE, plc VARCHAR2, sitAnt NUMBER, jornAnt NUMBER, jorUpd NUMBER DEFAULT NULL) IS
    totSit    NUMBER(10);
    aux       NUMBER(10);
    auxDtFim  VARCHAR2(8);
    auxDtIni  VARCHAR2(8);

  BEGIN
    
    IF(jorUpd IS NOT NULL)THEN 

      DBMS_OUTPUT.PUT_LINE('[UPDATE SIT] FINALIZA SITUACAO EMP:'||emp||' | COND:'||cond||' | sit:'||sit||' | sitAnt:'||sitAnt||' | dtIni:'||dtIni||' | dtFim:'||dtFim);
      UPDATE jornada SET
      data_fim = dtFim
      WHERE condutor = cond
      AND id_jornada = jorUpd;

    ELSE 

      DBMS_OUTPUT.PUT_LINE('[UPDATE SIT] FINALIZA SITUACAO EMP:'||emp||' | COND:'||cond||' | sit:'||sit||' | sitAnt:'||sitAnt||' | dtIni:'||dtIni||' | dtFim:'||dtFim);
      UPDATE jornada SET
      data_fim = dtFim
      WHERE condutor = cond
      AND data_ini <= dtFim
      AND data_fim IS NULL;

    END IF;
  END;
/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/
  
  PROCEDURE endRegera(cond NUMBER, emp NUMBER, plc VARCHAR2, dtHr DATE) IS
    dtFimAux  VARCHAR2(8);
    dtFimDt     DATE;
    sitAuxFim NUMBER(10);
  BEGIN
    --encerra a ultima situacao caso seja uma regeracao de dia
    IF(TRUNC(dtHr) < TRUNC(SYSDATE) AND dtHr IS NOT NULL)THEN
      dtFimAux := to_char(dtHr, 'DDMMYYYY');
      dtFimDt  := to_date(dtFimAux||' 23:59', 'DDMMYYYY HH24:MI');
      IF(gblJor.situacao IS NOT NULL)THEN
        sitAuxFim := regraSituacaoFim(emp, cond, gblJor.situacao, null, dtFimDt, dtFimDt);
      END IF;
      updateSit(cond, emp, gblJor.situacao, null, dtFimDt, plc, gblJor.situacao, gblJor.id_jornada);
    END IF;
  END;
  
  /****** FUNCTIONS ********/
/*
802 - Jornada Iniciada
803 - Jornada Finalizada
804 - Refeição Iniciada
805 - Refeição Finalizada
806 - Descanso Iniciado
807 - Descanso Finalizado
808 - Espera Iniciada
809 - Espera Finalizada
816 - Manobra Iniciada
817 - Manobra Finalizada*/
  FUNCTION regraSituacao(emp NUMBER, cond NUMBER, sit NUMBER, cod NUMBER, dtIni DATE, dtFim DATE) RETURN NUMBER AS
    sitAux NUMBER(10);
    diaAux CHAR(1);
    idConf NUMBER(10);
    
    tmpAux NUMBER(10);
    nexSit NUMBER(10);
    totSit NUMBER(10);
    
    dtAux DATE;
    
    auxEspera CHAR(1);
  BEGIN
    /**CADASTRO DE FERIADO**/
    diaAux := to_char(dtIni, 'D');
--    IF(diaAux<>1)THEN
--      SELECT 
--    END IF;
  
    IF((sit=gblRepouso AND cod IS NULL) OR (sit IS NULL and cod IS NULL))THEN -- se a situacao anterior é repouso e nao tem evento de jornada retorna repouso
      sitAux := gblRepouso; 
    ELSIF(cod = 804)THEN
      sitAux := gblRefeicao;
    ELSIF(cod = 806)THEN
      sitAux := gblDescanso;
    ELSIF(cod = 808)THEN --ESPERA
      --Configuração de Espera dentro ou fora da jornada foi mais simples ter uma flag na tablea configuração para a empresa
      --Toda empresa que não estivar na tabela configuração, gera DEFAULT - espera dentro da jornada
      --conferir se a empresa tem configuração de espera dentro da jornada
      -- T = espera dentro da jornada  | F = espera somente depois das horas de jornada cadastrada
      BEGIN
        SELECT espera, NVL(tempo, 480) INTO auxEspera, tmpAux
        FROM configuracao, configuracao_situacao
        WHERE empresa = emp
        AND configuracao.id_configuracao = configuracao_situacao.CONFIGURACAO
        AND situacao = 5;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        auxEspera := 'T';
      END;     
      
      IF(auxEspera='F')THEN
        totSit := getTotalJornada(cond, dtIni, 5);
        IF(totSit>tmpAux)THEN
          sitAux := gblEspera;
        END IF;
      ELSE 
        sitAux := gblEspera;
      END IF;      
    ELSE
      BEGIN
        SELECT id_configuracao INTO idConf
        FROM configuracao
        WHERE empresa = emp;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        idConf := 1;
      END;     
      
      BEGIN
        SELECT ec.situacao, ec.tempo, ec.next_sit INTO sitAux, tmpAux, nexSit
        FROM configuracao_situacao ec, config_situacao_codigo ecc
        WHERE ecc.codigo = cod
        AND ecc.config_situacao = id_config_situacao
        AND ecc.dia = diaAux
        AND ec.configuracao = idConf;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        BEGIN
          SELECT ec.situacao, ec.tempo, ec.next_sit INTO sitAux, tmpAux, nexSit
          FROM configuracao_situacao ec, config_situacao_codigo ecc
          WHERE ecc.codigo = cod
          AND ecc.config_situacao = id_config_situacao
          AND ecc.dia = 0
          AND ec.configuracao = idConf;
        EXCEPTION WHEN NO_DATA_FOUND THEN
          sitAux := 4;
          tmpAux := null;
        END;
      END;
      IF(tmpAux IS NOT NULL)THEN
          totSit := getTotalJornada(cond, dtIni, sitAux);
          IF(totSit>=tmpAux)THEN
            sitAux := nexSit;
          END IF;
      END IF;
    END IF;    
    DBMS_OUTPUT.put_line('[GET CONFIG INI] TEMPO=>'||tmpAux||' TOTAL=>'||totSit||' SIT=>'||sitAux||' EMP=>'||emp||' idConf=>'||idConf||' DIA=>'||diaAux||' NEXT SIT=>'||nexSit);
    RETURN sitAux;
  END;

  FUNCTION regraSituacaoFim(emp NUMBER, cond NUMBER, sit NUMBER, cod NUMBER, dtIni DATE, dtFim DATE) RETURN NUMBER AS
    sitAux NUMBER(10);
    diaAux CHAR(1);
    idConf NUMBER(10);
    idConfSit NUMBER(10);
    
    tmpDes NUMBER(10);
    tmpAux NUMBER(10);
    tmpMin NUMBER(10);
    nexSit NUMBER(10);
    totSit NUMBER(10);
    
    ctrTot CHAR(1); --variavel para controle se o tempo/tempo_min é para a soma das situacoes ou para uma situacao
    dtIniAux DATE;
    dtAux    DATE;
    dtChar   VARCHAR2(8);
  BEGIN
    diaAux := to_char(dtFim, 'D');
    totSit := null;
    BEGIN
      SELECT id_configuracao INTO idConf
      FROM configuracao
      WHERE empresa = emp;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      idConf := 1;
    END;
      
    tmpDes := 0;  
    BEGIN
      SELECT id_config_situacao, situacao, tempo, tempo_min, tempo_desconto, next_sit, total INTO idConfSit, sitAux, tmpAux, tmpMin, tmpDes, nexSit, ctrTot
      FROM (SELECT id_config_situacao, situacao, tempo, tempo_min, tempo_desconto, next_sit, total
            FROM configuracao_situacao
            WHERE situacao = sit
            AND configuracao = idConf
            AND ativo = 'T'
            AND (tempo IS NOT NULL 
                 OR hora_ini IS NOT NULL 
                 OR hora_fim IS NOT NULL 
                 OR tempo_min IS NOT NULL)
            ORDER BY id_config_situacao DESC)
      WHERE ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      sitAux := null;
      tmpAux := null;
      tmpMin := null;
      tmpDes := 0;
    END;
    dtIniAux := gblJor.data_ini; 

--    --somente entra nessa condicao se vier do UPDATE que encerra uma situacao dtFIM is not null  
    IF(tmpAux IS NOT NULL AND dtFim IS NOT NULL)THEN
      --controle para a soma da situacao ou somente a ultima situacao
      totSit := getTotalJornada(cond, dtFim, sitAux, ctrTot);
      DBMS_OUTPUT.put_line('[REGRA SITUACAO FIM 1] DTFIM=>'||dtFim||' DIA=>'||diaAux||' || SITUACAO=>'||sit||' TEMPO MIN=>'||tmpMin||' TEMPO AUX=>'||tmpAux||' TOTAL=>'||totSit||' NEXT SIT=>'||nexSit);
      IF(totSit>tmpAux)THEN
      --controla a conversao da espera em repouso (ex: apos 6 horas de espera transforma 2 em espera e o restante em repouso)
        IF(tmpDes>0)THEN
          dtAux :=  dtIniAux+(ABS((totSit-tmpDes)-ROUND((dtFim-dtIniAux)*1440)))/1440;
          dbms_output.put_line('[REGRA SITUACAO FIM 2] TEMPO MAX ESPERA: DTINI=>'||dtIniAux||' DTFIM=>'||dtFim||' NEWDT=>'||dtAux||' DIA=>'||diaAux||' || SITUACAO=>'||sitAux||' TEMPO=>'||tmpAux||' TEMPO DESC=>'||tmpDes||' TOTAL=>'||totSit||' NEXT SIT=>'||nexSit);
          updateSit(cond, emp, sit, null, dtAux, null, null, gblJor.id_jornada, gblJor.id_jornada);
          insertSit(cond, emp, nexSit, dtAux, null, null, sit, gblJor.id_jornada); 
          setGblSit(cond, dtAux);
          geraAlerta(emp, cond, idConfSit, sit, gblJor.data_ini, dtAux);
          sitAux := 0;--sitAux = 0 para controle sair do laço e não executar o update ou insert seguinte
        ELSIF(gblJor.id_jornada IS NOT NULL)THEN
          dtAux :=  dtIniAux+(ABS((totSit-tmpAux)-ROUND((dtFim-dtIniAux)*1440)))/1440;
          dbms_output.put_line('[REGRA SITUACAO FIM 3] TEMPO MAX DTFIM=>'||dtFim||' DIA=>'||diaAux||' || SITUACAO=>'||sitAux||' TEMPO=>'||tmpAux||' TEMPO DESC=>'||tmpDes||' TOTAL=>'||totSit||' NEXT SIT=>'||nexSit);
          updateSit(cond, emp, nexSit, null, dtAux, null, null, gblJor.id_jornada);
          insertSit(cond, emp, nexSit, dtAux, null, null, sit, gblJor.id_jornada); 
          sitAux := nexSit;
        END IF;
      END IF;
    END IF;
    
    --controle do tempo minimo de situacao
    IF(tmpMin IS NOT NULL AND dtFim IS NOT NULL AND to_char(dtFim, 'HH24MI') <> '2359')THEN
      --controle para a soma da situacao ou somente a ultima situacao
      totSit := getTotalJornada(cond, dtFim, sitAux, ctrTot);
      IF(totSit<tmpMin AND gblJor.id_jornada IS NOT NULL)THEN
        dbms_output.put_line('[REGRA SITUACAO FIM 4] TEMPO MIN DTFIM=>'||dtFim||' DIA=>'||diaAux||' || SITUACAO=>'||sitAux||' TEMPO MIN=>'||tmpMin||' TOTAL=>'||totSit||' NEXT SIT=>'||nexSit);
        
        IF(gblJor.situacao=6)THEN--tempo minimo de refeicao
          geraAlerta(emp, cond, idConfSit, sitAux, dtIni, dtFim);
        
        ELSIF(gblJor.situacao=4)THEN--tempo minimo de repouso
          --exclui a situacao que não atendeu o tempo minimo
          DELETE FROM jornada 
          WHERE id_jornada = gblJor.id_jornada
          AND condutor = cond;
          --transforma a situacao anterior em situacao atual 
          UPDATE jornada SET
          data_fim = null
          WHERE id_jornada = (SELECT MAX(id_jornada) 
                              FROM jornada 
                              WHERE condutor = cond
                              AND data_fim <=dtIniAux
                              AND trunc(data_fim) = trunc(dtIniAux))
          AND data_fim IS NOT NULL
          AND trunc(data_fim) = trunc(dtIniAux)
          AND condutor = cond;
          
          --reset das variaveis globais
          setGblSit(cond, dtIniAux);
          geraAlerta(emp, cond, idConfSit, sitAux, dtIni, dtFim);
        END IF;
        
      END IF;
    END IF;

    RETURN sitAux;
  END;
  
  
  PROCEDURE setGblSit(cond NUMBER, dtHr DATE) IS
  BEGIN
    BEGIN 
      SELECT id_jornada, situacao, data_ini, data_fim, jornada_ant
        INTO gblJor.id_jornada, gblJor.situacao, gblJor.data_ini, gblJor.data_fim, gblJor.jornada_ant
      FROM (SELECT id_jornada, situacao, data_ini, data_fim, jornada_ant
            FROM jornada 
            WHERE condutor = cond
            AND data_ini <= dtHr
            ORDER BY data_fim DESC)
      WHERE ROWNUM = 1;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      gblJor.id_jornada  := null;
      gblJor.situacao    := null;
      gblJor.data_ini    := null;
      gblJor.data_fim    := null;
      gblJor.jornada_ant := null;
    END;
    DBMS_OUTPUT.PUT_LINE('[GLOBAL SITUACAO] ID:'||gblJor.id_jornada||' SIT:'||gblJor.situacao||' DTINI:'||gblJor.data_ini||' DTFIM:'||gblJor.data_fim||' JORANT:'||gblJor.jornada_ant);
    gblJor.condutor   := cond;
  END;
  
  
  FUNCTION getPlaca(cond NUMBER, dtHr DATE) RETURN VARCHAR2 AS
    plc VARCHAR2(10);
  BEGIN
    
    BEGIN 
      SELECT placa INTO plc
      FROM (SELECT placa
            FROM monitoramento.condutor_historico
            WHERE condutor = cond
            AND ((dtHr BETWEEN data_ini AND data_fim)
                OR (data_ini <= dtHr AND data_fim IS NULL))
            ORDER BY data_ini DESC)
      WHERE ROWNUM = 1 ;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      plc := null;
    END;
    
    RETURN plc;
  END;


  FUNCTION getTotalJornada(cond NUMBER, dtHr DATE, sit NUMBER, crtlTot CHAR DEFAULT 'T') RETURN NUMBER AS
    totSit NUMBER(10);
    totAux NUMBER(10);
    dtAux DATE;
  BEGIN
    dtAux := gblJor.data_ini;
    IF(crtlTot = 'T')THEN
      BEGIN 
        SELECT SUM((extract(day from TOT )*1440)+
                   (extract(hour from TOT )*60)+
                   (extract(minute from TOT)))
          INTO totSit
        FROM (SELECT data_fim-data_ini tot
              FROM jornada
              WHERE condutor = cond
              AND TRUNC(data_ini) = trunc(dtHr)
              AND TRUNC(data_fim) = trunc(dtHr)
              AND data_ini >= (SELECT NVL(MAX(data_fim), to_date(to_char(dtHr, 'DDMMYYYY')||'00:00', 'DDMMYYYY HH24:MI'))
                               FROM jornada 
                               WHERE condutor = cond 
                               AND situacao = 4
                               AND TRUNC(data_ini) = trunc(dtHr)
                               AND data_ini < dtHr
                               AND to_char(data_ini, 'HH24MI')<>'0000'
                               AND to_char(data_fim, 'HH24MI')<>'2359')
              AND data_fim IS NOT NULL
              AND situacao = sit);
      EXCEPTION WHEN NO_DATA_FOUND THEN 
        totSit := 0;
      END;
      
      IF(totSit IS NULL)THEN 
        totSit := 0;
      END IF;
      /*PARA TRATAR SITUACAO DE JORNADA ENCERRADA SEM CALCULAR TEMPO MAXIMO DE JORNADA*/
      IF(sit=gblJor.situacao AND dtAux IS NOT NULL)THEN
        totSit := totSit + ((dtHr-dtAux)*1440);
      END IF;
      DBMS_OUTPUT.PUT_LINE('[GET TOTAL JORNADA] TOTAL SITUACAO:'||sit||' TEMPO:'||totSit||' DTHR:'||dtHr);
    --utilizado para pegar o total de uma determinada situacao   
    ELSIF(crtlTot='F')THEN
      totAux := 0;
      totSit := (dtHr-dtAux)*1440;
      --controle para identificar se a situacao iniciou no dia anterior
      IF(to_char(dtAux, 'HH24MI')= '0000')THEN
        BEGIN 
          SELECT SUM((extract(day from TOT )*1440)+
                     (extract(hour from TOT )*60)+
                     (extract(minute from TOT)))
            INTO totAux
          FROM (SELECT data_fim-data_ini tot
                FROM jornada
                WHERE condutor = cond
                AND TRUNC(data_ini) = trunc(dtAux-1)
                AND to_char(data_fim, 'HH24MI') = '2359'
                AND situacao = sit);
        EXCEPTION WHEN NO_DATA_FOUND THEN 
          totAux := 0;
        END;
      END IF;
      totSit := totSit+totAux;
      DBMS_OUTPUT.PUT_LINE('[GET TOTAL JORNADA] TOTAL SITUACAO UNICA:'||sit||' TEMPO:'||totSit);
    END IF;
    
    RETURN totSit;
  END;
  
  FUNCTION getEmpCond(cond NUMBER) RETURN NUMBER AS
    emp NUMBER(10);
  BEGIN
    BEGIN 
      SELECT empresa INTO emp
      FROM monitoramento.condutor
      WHERE id_condutor = cond;
    EXCEPTION WHEN NO_DATA_FOUND THEN
      emp := null;
    END;
    RETURN emp;
  END;

  PROCEDURE geraAlerta(emp NUMBER, cond NUMBER, config NUMBER, sit NUMBER, dtIni DATE, dtFim DATE) IS
    auxAlerta VARCHAR2(20);
    auxTmp    NUMBER(10);
  BEGIN
    DBMS_OUTPUT.PUT_LINE('*****************************************************************************');
    DBMS_OUTPUT.PUT_LINE('*******************************[getAlerta] **********************************');
    DBMS_OUTPUT.PUT_LINE('*****************************************************************************');
    auxTmp := getIntervalToNumber(gblJor.data_ini, dtFim);
    INSERT INTO alertas
    (id_alerta, descricao, data_hora, placa, condutor, jornada)
    (SELECT seq_alertas.nextval, alsit.descricao||': '||auxTmp, gblJor.data_ini, gblJor.placa, cond, gblJor.id_jornada
     FROM alerta_situacao alsit
     WHERE alsit.empresa IS NULL
     AND config_situacao = config);
  END;

END PKG_JORNADA;
/
