CREATE PACKAGE PKG_ALERTAS AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE geraAlertaMovimento;
END PKG_ALERTAS;
/
