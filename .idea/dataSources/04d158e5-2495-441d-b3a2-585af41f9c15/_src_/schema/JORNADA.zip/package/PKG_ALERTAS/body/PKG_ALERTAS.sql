CREATE PACKAGE BODY PKG_ALERTAS AS

  PROCEDURE geraAlertaMovimento IS
    plc   VARCHAR2(8);
    dtIg  DATE;
    tmp   NUMBER(10);
  BEGIN
    INSERT INTO alertas
    (id_alerta, descricao, data_hora, placa, condutor)
    (SELECT seq_alertas.nextval, 'TEMPO DE DIREÇÃO EXCEDIDO: '||to_char((SYSDATE-rota.data_ignicao)*1440, '9990,0'), SYSDATE, veiculo.placa, veiculo.condutor
    FROM empresa_jornada ej, monitoramento.veiculo, monitoramento.rota
    WHERE ej.empresa = veiculo.empresa
    AND veiculo.placa = rota.placa
    AND rota.ignicao = 1
    AND TRUNC(rota.data_hora) > TRUNC(SYSDATE-240/1440) --a placa tem que estar com dado atualizado das ultimas 4 horas
    AND rota.data_ignicao < SYSDATE-(240/1440));
  END;
  
END PKG_ALERTAS;
/
