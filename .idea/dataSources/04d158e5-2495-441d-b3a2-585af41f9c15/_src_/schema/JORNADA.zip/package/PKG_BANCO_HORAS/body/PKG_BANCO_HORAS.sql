CREATE PACKAGE BODY PKG_BANCO_HORAS AS

  /*
  DECLARE
    start_date  NUMBER;
    end_date    NUMBER;
    idEmpresa   NUMBER;
  BEGIN
    --idEmpresa := '98692';
  
    --Limpando tudo para calcular novamente:
    DELETE
    FROM banco_fechamento;
    
    DELETE
    FROM banco_condutor_dia;
    
    UPDATE banco_condutor
    SET acumulado   = 0,
        saldo_atual = 0; 
    
    COMMIT;
    
    start_date  := to_number(to_char(to_date('01/01/2017', 'DD/MM/YYYY'), 'j'));
    end_date    := to_number(to_char(to_date('01/02/2017', 'DD/MM/YYYY'), 'j'));
    FOR cur_r IN start_date..end_date LOOP
      BEGIN
        pkg_banco_horas.geraBancoCondutorDia(to_date(cur_r, 'j'), idEmpresa); 
        COMMIT;
      END;
    END LOOP; 
  END;
  
  --
  
  DECLARE
    start_date  NUMBER;
    end_date    NUMBER;
  BEGIN
    start_date  := to_number(to_char(to_date('01/04/2017', 'DD/MM/YYYY'), 'j'));
    end_date    := to_number(to_char(to_date('01/04/2017', 'DD/MM/YYYY'), 'j'));
    FOR cur_r IN start_date..end_date LOOP
      BEGIN
        pkg_banco_horas.geraBancoCondutorDia(to_date(cur_r, 'j')); 
        COMMIT;
      END;
    END LOOP; 
  END;
  */

  --Variaveis Globais:
  gblJor jornada%ROWTYPE;

  --Busca os valores totais da jornada
  PROCEDURE geraBancoCondutorDia (dt DATE, idEmpresa NUMBER DEFAULT NULL) AS

    totalJornadaDia         NUMBER(10) 		:= 0;
    aucumuladoTotal 	      NUMBER(10) 		:= 0;
    rowAcumuladoAnterior    NUMBER(10) 		:= 0;
    rowIdCondutor 			    NUMBER(10) 		:= 0;
    rowIdEmpresa  	        NUMBER(10) 		:= 0;
    rowIdBancoHora		 	    NUMBER(10) 		:= 0;
    rowIdBancoCondutor	    NUMBER(10) 		:= 0;
    rowMinSemana 			      NUMBER(10) 		:= 0;
    rowMinSabado		 		    NUMBER(10) 		:= 0;
    rowMinTotal 		 		    NUMBER(10) 		:= 0;
    rowSaldoAtual		 	      NUMBER(10) 		:= 0;
    rowSaldoIni		 	        NUMBER(10) 		:= 0;
    rowPeriodoBH	 	        NUMBER(10) 		:= 0;
    saldoDia	 		          NUMBER(10) 		:= 0;
    acumuladoDia  	        NUMBER(10) 		:= 0;
    acumuladoTotal	        NUMBER(10) 		:= 0;
    acumuladoAtual 	        NUMBER(10) 		:= 0;
    auxIdEmpresa  	        NUMBER(10) 		:= 0;
    mediaTrabDia  	        NUMBER(10) 		:= 0;
    mediaTrabSem  	        NUMBER(10) 		:= 0;
    diasDeTrab    	        NUMBER(10) 		:= 0;
    totalFeriado   	        NUMBER(10) 		:= 0;
    totalDescanso  	        NUMBER(10) 		:= 0;
    totalDiasDobrados       NUMBER(10) 		:= 0;
    
    charFeriado 				    VARCHAR(1)    := 'F';
    charDescanso		        VARCHAR(1) 		:= 'F';
    dtChar                  VARCHAR2(10)  := '';
    sqlBancoCondutor        VARCHAR2(9000):= '';
    sqlAux                  VARCHAR2(9000):= '';
    
    rowDataIniBC            DATE;
    rowDataFimBC            DATE;
    
    cursor_banco_condutor 	SYS_REFCURSOR;
    
  BEGIN
    dtChar := to_char(dt, 'DDMMYYYY');
  
    --Consultando os condutores que possuem banco de horas em aberto (dados da tabela BANCO_CONDUTOR)
    FOR cursor_banco_condutor IN (
      SELECT
        bc.id_banco_condutor,
        bc.condutor,
        bc.acumulado,
        bc.saldo_atual,
        bc.saldo_ini,
        bh.empresa,
        bh.min_semana,
        bh.min_sab,
        bh.id_banco_horas,
        bc.data_ini,
        bc.data_fim,
        bh.periodo,
        bc.min_total
      FROM banco_condutor bc, banco_horas bh
      WHERE bc.ID_BANCO_HORAS = bh.ID_BANCO_HORAS
    )
    LOOP
      --Capturando variaveis necessarias para manipulacao
      rowIdBancoCondutor    := cursor_banco_condutor.id_banco_condutor;
      rowIdCondutor			    := cursor_banco_condutor.condutor;
      rowIdEmpresa 	        := cursor_banco_condutor.empresa;
      rowIdBancoHora	      := cursor_banco_condutor.id_banco_horas;
      rowMinSemana			    := cursor_banco_condutor.min_semana;
      rowMinSabado			    := cursor_banco_condutor.min_sab;
      rowMinTotal 			    := cursor_banco_condutor.min_total;
      rowAcumuladoAnterior  := cursor_banco_condutor.acumulado;
      rowSaldoAtual         := cursor_banco_condutor.saldo_atual;
      rowSaldoIni           := cursor_banco_condutor.saldo_ini;
      rowDataIniBC          := cursor_banco_condutor.data_ini;
      rowDataFimBC          := cursor_banco_condutor.data_fim;
      rowPeriodoBH          := cursor_banco_condutor.periodo;

--    IF(idEmpresa != NULL) THEN
--      sqlAux := 'AND bh.empresa = '||idEmpresa;
--    END IF;
      
--    sqlBancoCondutor := '
--        SELECT
--          bc.id_banco_condutor,
--          bc.condutor,
--          bc.acumulado,
--          bc.saldo_atual,
--          bc.saldo_ini,
--          bh.empresa,
--          bh.min_semana,
--          bh.min_sab,
--          bh.id_banco_horas,
--          bc.data_ini,
--          bc.data_fim
--        FROM banco_condutor bc, banco_horas bh
--        WHERE bc.ID_BANCO_HORAS = bh.ID_BANCO_HORAS'
--        ||sqlAux;
          
--    DBMS_OUTPUT.PUT_LINE('sql BANCO_CONDUTOR: '||sqlBancoCondutor);
      
--    OPEN cursor_banco_condutor FOR sqlBancoCondutor;
--    LOOP FETCH cursor_banco_condutor INTO rowIdBancoCondutor, rowIdCondutor, rowIdEmpresa, rowIdBancoHora, rowMinSemana, rowMinSabado, rowAcumuladoAnterior, rowSaldoAtual, rowSaldoIni, rowDataIniBH, rowDataFimBH;
      
      --Total de jornada (5)
      totalJornadaDia 	  := getTotalSituacao(rowIdCondutor, dtChar, 5) + getTotalSituacao(rowIdCondutor, dtChar, 9) + getTotalSituacao(rowIdCondutor, dtChar, 10);
      
      --Teste para controle de consulta na tabela de feriado, consultando apenas quando trocar a empresa do condutor da linha
      IF(auxIdEmpresa <> rowIdEmpresa) THEN
         charFeriado := consultaFeriado(dtChar, rowIdEmpresa);
      END IF;
      
      auxIdEmpresa := rowIdEmpresa;
      
      IF(to_char(dt, 'D') = '1') THEN
        --DBMS_OUTPUT.PUT_LINE('Domingo');
        acumuladoDia    := totalJornadaDia * 2;
        saldoDia        := acumuladoDia;
        charDescanso    := 'T';
      ELSIF(to_char(dt, 'D') = '7') THEN
        --DBMS_OUTPUT.PUT_LINE('Sabado');
        saldoDia        := totalJornadaDia - rowMinSabado;
        acumuladoDia    := totalJornadaDia;
      ELSE
        IF(charFeriado = 'T') THEN
          --DBMS_OUTPUT.PUT_LINE('Feriado');
          acumuladoDia    := totalJornadaDia * 2;
          saldoDia        := acumuladoDia;
          charFeriado     := 'T';
        ELSE
          --DBMS_OUTPUT.PUT_LINE('Dia normal');
          saldoDia        := totalJornadaDia - rowMinSemana;
          acumuladoDia    := totalJornadaDia;
        END IF;
      END IF;
      
      acumuladoTotal  := acumuladoDia + rowAcumuladoAnterior;
      
      --Insert na tabela BANCO_CONDUTOR_DIA com os valores gerados acima
      INSERT INTO banco_condutor_dia
        (id_bc_dia, data, condutor, acumulado_ant, minutos_trab, acumulado_total, feriado, dia_descanso, id_banco_cond, saldo, acumulado_dia)
      VALUES
        (SEQ_BANCO_CONDUTOR_DIA.nextval, dtChar, rowIdCondutor, rowAcumuladoAnterior, totalJornadaDia, acumuladoTotal, charFeriado, charDescanso, rowIdBancoCondutor, saldoDia, acumuladoDia);

      --Trabalhando os dados e atualizando a tabela BANCO_CONDUTOR
      acumuladoAtual	:= rowAcumuladoAnterior + acumuladoDia;
      rowSaldoAtual 	:= rowSaldoAtual + saldoDia;

      UPDATE banco_condutor
      SET acumulado = acumuladoAtual,
          saldo_atual = rowSaldoAtual
      WHERE condutor = rowIdCondutor;
      
      --Fechamento (BANCO_FECHAMENTO) Apenas se a data de fim do banco_condutor for igual a data que está sendo gerada      
      IF(to_date(dtChar) = rowDataFimBC) THEN
        
        --Média de trabalho por dia
        diasDeTrab := rowDataFimBC - rowDataIniBC;
        mediaTrabDia := acumuladoAtual / diasDeTrab;
        
        --Média de trabalho por semana
        mediaTrabSem := acumuladoAtual / 7;
        
        --Soma de dias de horas dobradas
        SELECT count(*) into totalFeriado
        FROM banco_condutor_dia
        WHERE feriado = 'T'
              AND minutos_trab > 0
              AND condutor = ''||rowIdCondutor||'';
                  
        SELECT count(*) into totalDescanso
        FROM banco_condutor_dia
        WHERE dia_descanso = 'T'
              AND minutos_trab > 0
              AND condutor = ''||rowIdCondutor||'';
              
        totalDiasDobrados := totalDescanso + totalFeriado;
        
        INSERT INTO banco_fechamento
        (id_banco_fechamento, 
          condutor, 
          saldo, 
          data_ini, 
          data_fim,
          id_banco_horas, 
          total_trabalhado,
          saldo_ini,
          media_trab_dia,
          media_trab_sem,
          dias_valor_dobrado,
          total_previsto)
        VALUES
        (SEQ_BANCO_FECHAMENTO.nextval, 
          rowIdCondutor, 
          rowSaldoAtual, 
          rowDataIniBC, 
          rowDataFimBC, 
          rowIdBancoHora,
          acumuladoAtual,
          rowSaldoIni,
          mediaTrabDia,
          mediaTrabSem,
          totalDiasDobrados,
          rowMinTotal);
          
        --Atualizando para o proximo periodo os dados dados da tabela banco_condutor
        UPDATE banco_condutor
        SET saldo_ini = 0,
            acumulado = 0,
            saldo_atual = 0,
            data_ini = rowDataFimBC + 1, 
            data_fim = add_months(rowDataFimBC + 1, rowPeriodoBH)
        WHERE id_banco_horas = rowIdBancoHora;
        
        --Atualizando o total de horas totais a serem realizadas no próximo período
        setTotalBancoHoras(''||rowIdBancoHora||'', rowDataFimBC + 1, add_months((rowDataFimBC - 1) + 1, rowPeriodoBH));
        
      END IF;
--    EXIT WHEN cursor_banco_condutor%NOTFOUND;
    END LOOP;
--    CLOSE cursor_banco_condutor; 
    DBMS_OUTPUT.PUT_LINE('FIM CONDUTOR_DIA - '||dt);
  END geraBancoCondutorDia;
  
  --Função que testa se determinada data é um feriado para a empresa  
  FUNCTION consultaFeriado(dt VARCHAR, idEmpresa NUMBER) RETURN VARCHAR AS
  
    sqlAuxFeriado		    VARCHAR2  (2000)    := '';
    feriado             VARCHAR   (2000)    := 'F';
    data_feriado			  VARCHAR2  (10)      := '';    
    countFeriado        NUMBER    (2)       := 0;
    cursor_feriado 			SYS_REFCURSOR;
  
  BEGIN
    sqlAuxFeriado := '
      SELECT to_char(data_feriado, ''DD/MM/YY'') as data_feriado
      FROM feriado
      WHERE empresa = '||idEmpresa||'
          AND trunc(data_feriado) = to_date('''||dt||''', ''DD/MM/YY'')';
    
    OPEN cursor_feriado FOR sqlAuxFeriado;
    --Percorrendo o retorno da consulta de feriados
    LOOP FETCH cursor_feriado INTO data_feriado;
      countFeriado := countFeriado + 1;     
      EXIT WHEN cursor_feriado%NOTFOUND;
    END LOOP;
    
    IF(countFeriado > 1) THEN
      feriado := 'T';
    END IF;
    
    --DBMS_OUTPUT.PUT_LINE('RETORNO DA CONSULTA FERIADO: '||feriado);
    RETURN feriado;
  END;
  
  --Função que calcula o total de de jornada a ser feita pelo condutor baseado nas hora previstas do dia (definidas pelo usuario que cadastrou o banco de horas)
  PROCEDURE setTotalBancoHoras(idBancoHoras NUMBER, dtIni DATE, dtFim DATE) AS
    totalHoras      NUMBER := 0;
    start_date      NUMBER;
    end_date        NUMBER;
    minSem          NUMBER;
    minSab          NUMBER;
    idEmpresa       NUMBER;
    teste           VARCHAR2(5000) := '';
    dtVarchar       VARCHAR(10);
    charFeriado     CHAR(2000);
    countTeste      NUMBER := 0;
  BEGIN
  
    SELECT min_semana, min_sab, empresa INTO minSem, minSab, idEmpresa 
    FROM banco_horas 
    WHERE id_banco_horas = idBancoHoras;
  
    --start_date  := to_number(to_char(to_date(''||dtIni||'', 'DD/MM/YY'), 'j'));
    --end_date    := to_number(to_char(to_date(''||dtFim||'', 'DD/MM/YY'), 'j'));   
    
    start_date  := to_number(to_char(dtIni, 'j'));
    end_date    := to_number(to_char(dtFim, 'j'));   
    
    FOR dtLoop IN start_date..end_date LOOP
      countTeste := countTeste + 1;
      dtVarchar   := to_char(to_date(dtLoop, 'j'), 'DD/MM/YY');
      charFeriado := consultaFeriado(dtVarchar, idEmpresa);
      
      IF(charFeriado = 'F') THEN
        IF(to_char(to_date(dtLoop, 'j'), 'D') = '7') THEN
          --DBMS_OUTPUT.PUT_LINE('Sabado: '||charFeriado ||' calculo: '||totalHoras ||' + '|| minSab);
          totalHoras := totalHoras + minSab;
        ELSIF (to_char(to_date(dtLoop, 'j'), 'D') != '1') THEN
          --DBMS_OUTPUT.PUT_LINE('Semana: '||charFeriado ||' calculo: '||totalHoras ||' + '|| minSem);
          totalHoras := totalHoras + minSem;
        END IF;          
      END IF;
      
    END LOOP;
    
    UPDATE banco_condutor
    SET min_total = totalHoras--,
        --set abaixo para testes
        --teste = countTeste
    WHERE id_banco_horas = idBancoHoras;
  END;  

  --Função que retorna o total de tempo de uma determinada situação
  FUNCTION getTotalSituacao(cond NUMBER, dtHr DATE, sit NUMBER, crtlTot CHAR DEFAULT 'T') RETURN NUMBER AS
    totSit NUMBER(10);
    totAux NUMBER(10);
    dtAux DATE;
    BEGIN
      dtAux := gblJor.data_ini;
      IF(crtlTot = 'T')THEN
        BEGIN
          SELECT
            SUM((extract(day from TOT )*1440)+
                (extract(hour from TOT )*60)+
                (extract(minute from TOT))) INTO totSit
          FROM (SELECT data_fim-data_ini tot
                FROM jornada
                WHERE condutor = cond
                      AND TRUNC(data_ini) = trunc(dtHr)
                      AND TRUNC(data_fim) = trunc(dtHr)
                      AND data_ini >= (
                  SELECT NVL(MAX(data_fim), to_date(to_char(dtHr, 'DDMMYYYY')||'00:00', 'DDMMYYYY HH24:MI'))
                  FROM jornada
                  WHERE condutor = cond
                        AND situacao = 4
                        AND TRUNC(data_ini) = trunc(dtHr)
                        AND data_ini < dtHr
                        AND to_char(data_ini, 'HH24MI')<>'0000'
                        AND to_char(data_fim, 'HH24MI')<>'2359')
                      AND data_fim IS NOT NULL
                      AND situacao = sit);
          EXCEPTION WHEN NO_DATA_FOUND THEN
          totSit := 0;
        END;

        IF(totSit IS NULL)THEN
          totSit := 0;
        END IF;
        /*PARA TRATAR SITUACAO DE JORNADA ENCERRADA SEM CALCULAR TEMPO MAXIMO DE JORNADA*/
        IF(sit=gblJor.situacao AND dtAux IS NOT NULL)THEN
          totSit := totSit + ((dtHr-dtAux)*1440);
        END IF;
        --DBMS_OUTPUT.PUT_LINE('TOTAL JORNADA: '||totSit||' DTHR:'||dtHr);
        --utilizado para pegar o total de uma determinada situacao
      ELSIF(crtlTot='F')THEN
        totAux := 0;
        totSit := (dtHr-dtAux)*1440;
        --controle para identificar se a situacao iniciou no dia anterior
        IF(to_char(dtAux, 'HH24MI')= '0000')THEN
          BEGIN
            SELECT
              SUM((extract(day from TOT )*1440)+
                  (extract(hour from TOT )*60)+
                  (extract(minute from TOT))) INTO totAux
            FROM (SELECT data_fim-data_ini tot
                  FROM jornada
                  WHERE condutor = cond
                        AND TRUNC(data_ini) = trunc(dtAux-1)
                        AND to_char(data_fim, 'HH24MI') = '2359'
                        AND situacao = sit);
            EXCEPTION WHEN NO_DATA_FOUND THEN
            totAux := 0;
          END;
        END IF;
        totSit := totSit+totAux;
        --DBMS_OUTPUT.PUT_LINE('[GET TOTAL JORNADA] TOTAL SITUACAO UNICA:'||sit||' TEMPO:'||totSit);
      END IF;
      RETURN totSit;
    END;

END PKG_BANCO_HORAS;
/
