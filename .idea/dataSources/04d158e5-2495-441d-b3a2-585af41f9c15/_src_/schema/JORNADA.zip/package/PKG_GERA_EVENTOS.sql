CREATE PACKAGE PKG_GERA_EVENTOS AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE getDados(cond NUMBER, emp NUMBER, dtini DATE, dtfim DATE);
  PROCEDURE checkStatus(placa_aux IN VARCHAR2, data_aux IN DATE, pacote_aux IN VARCHAR2, condutor_aux number, empresa_aux integer);
  PROCEDURE insertEvento(plc VARCHAR2, cond NUMBER, cod NUMBER, dt DATE, dados VARCHAR2 );
  

  PROCEDURE corrigeEventos(dt DATE);

  FUNCTION dec2bin (numero IN NUMBER) RETURN VARCHAR2;
  FUNCTION hex2dec (hexval IN CHAR) RETURN NUMBER;
  
END PKG_GERA_EVENTOS;
/
