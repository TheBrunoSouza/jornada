CREATE PACKAGE PKG_JORNADA_CORRECAO AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE beginjornada(cond NUMBER, emp NUMBER, dt DATE);
  PROCEDURE insertSit(cond NUMBER, emp NUMBER, sit NUMBER, dtIni DATE, dtFim DATE, plc VARCHAR2, sitAnt NUMBER, jornAnt NUMBER);
  PROCEDURE updateSit(cond NUMBER, emp NUMBER, sit NUMBER, dtIni DATE, dtFim DATE, plc VARCHAR2, sitAnt NUMBER, jornAnt NUMBER, jorUpd NUMBER DEFAULT NULL);
  
  PROCEDURE endRegera(cond NUMBER, emp NUMBER, plc VARCHAR2, dtHr DATE);
  
  FUNCTION  regraSituacao(emp NUMBER, cond NUMBER, sit NUMBER, cod NUMBER, dtIni DATE, dtFim DATE) RETURN NUMBER;
  FUNCTION  regraSituacaoFim(emp NUMBER, cond NUMBER, sit NUMBER, cod NUMBER, dtIni DATE, dtFim DATE) RETURN NUMBER;
  PROCEDURE setGblSit(cond NUMBER, dtHr DATE);
  FUNCTION  getPlaca(cond NUMBER, dtHr DATE) RETURN VARCHAR2;
  FUNCTION getTotalJornada(cond NUMBER, dtHr DATE, sit NUMBER, crtlTot CHAR DEFAULT 'T') RETURN NUMBER;
  FUNCTION getEmpCond(cond NUMBER) RETURN NUMBER;
  
  PROCEDURE geraAlerta(emp NUMBER, cond NUMBER, config NUMBER, sit NUMBER, dtIni DATE, dtFim DATE);
  
END PKG_JORNADA_CORRECAO;
/
