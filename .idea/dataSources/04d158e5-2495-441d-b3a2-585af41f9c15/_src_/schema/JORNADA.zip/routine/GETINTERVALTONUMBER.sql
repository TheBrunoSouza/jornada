CREATE FUNCTION GETINTERVALTONUMBER (DT_INI TIMESTAMP , DT_FIM TIMESTAMP ) RETURN NUMBER AS 
  tempo  INTERVAL DAY TO SECOND;
  tmpAux NUMBER(10);
BEGIN
  tempo := dt_fim - dt_ini;
  
  SELECT SUM((extract(day from tempo )*1440)+
             (extract(hour from tempo)*60)+
             (extract(minute from tempo))) INTO tmpAux
  FROM DUAL;
  
  RETURN tmpAux;
END GETINTERVALTONUMBER;
/
