CREATE FUNCTION GETINTERVALTOCHAR(DT_INI TIMESTAMP , DT_FIM TIMESTAMP ) RETURN VARCHAR2 AS 
  tempo  INTERVAL DAY TO SECOND;
  tmpAux NUMBER(10);
  hrs    NUMBER(10);
  minut  NUMBER(10);
BEGIN
  tempo := dt_fim - dt_ini;
  
  SELECT SUM((extract(day from tempo )*1440)+
             (extract(hour from tempo)*60)+
             (extract(minute from tempo))) INTO tmpAux
  FROM DUAL;
  
  hrs := TRUNC(tmpAux/60);
  minut := tmpAux-(hrs*60);
  
  RETURN TRIM(to_char(hrs, '900'))||':'||TRIM(to_char(minut, '00'));
  
END GETINTERVALTOCHAR;
/
